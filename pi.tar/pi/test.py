from __future__ import print_function

# pip3 install pytorch-lightning==1.2
# pip3 install git+https://github.com/romesco/hydra-lightning/#subdirectory=hydra-configs-pytorch-lightning
# pip3 install hydra-core --upgrade

"""From ObfuscatorTest"""
import os

def bID2Gender(label):
    new_label = label*0-1
    new_label[label==0] = 0
    new_label[label==1] = 0
    new_label[label==2] = 1
    new_label[label==3] = 1
    return new_label

def count_parameters(model):
    print("Number of parameters: %.3fM"%(sum(p.numel() for p in model.parameters() if p.requires_grad)/1e+6))
    return sum(p.numel() for p in model.parameters() if p.requires_grad)/1e+6

from ds2_classification import DeepSpeech as DS2Classifier
from ds2_classification import SpectConfig, AugmentationConfig
import torch.nn as nn
import torch
import numpy as np
b_print = False
# b_print = True

class GLU(nn.Module):
    def __init__(self):
        super(GLU, self).__init__()
        # Custom Implementation because the Voice Conversion Cycle GAN
        # paper assumes GLU won't reduce the dimension of tensor by 2.

    def forward(self, _input):
        return _input * torch.sigmoid(_input)


class PixelShuffle(nn.Module):
    def __init__(self, upscale_factor):
        super(PixelShuffle, self).__init__()
        # Custom Implementation because PyTorch PixelShuffle requires,
        # 4D input. Whereas, in this case we have have 3D array
        self.upscale_factor = upscale_factor

    def forward(self, _input):
        n = _input.shape[0]
        c_out = _input.shape[1] // 2
        w_new = _input.shape[2] * 2
        return _input.view(n, c_out, w_new)


##########################################################################################
class ResidualLayer(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding):
        super(ResidualLayer, self).__init__()

        self.conv1d_layer = nn.Sequential(nn.Conv1d(in_channels=in_channels,
                                                    out_channels=out_channels,
                                                    kernel_size=kernel_size,
                                                    stride=1,
                                                    padding=padding),
                                          nn.InstanceNorm1d(num_features=out_channels,
                                                            affine=True))

        self.conv_layer_gates = nn.Sequential(nn.Conv1d(in_channels=in_channels,
                                                        out_channels=out_channels,
                                                        kernel_size=kernel_size,
                                                        stride=1,
                                                        padding=padding),
                                              nn.InstanceNorm1d(num_features=out_channels,
                                                                affine=True))

        self.conv1d_out_layer = nn.Sequential(nn.Conv1d(in_channels=out_channels,
                                                        out_channels=in_channels,
                                                        kernel_size=kernel_size,
                                                        stride=1,
                                                        padding=padding),
                                              nn.InstanceNorm1d(num_features=in_channels,
                                                                affine=True))

    def forward(self, _input):
        h1_norm = self.conv1d_layer(_input)
        h1_gates_norm = self.conv_layer_gates(_input)

        # GLU
        h1_glu = h1_norm * torch.sigmoid(h1_gates_norm)

        h2_norm = self.conv1d_out_layer(h1_glu)
        return _input + h2_norm

##########################################################################################
class downSample_Generator(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding):
        super(downSample_Generator, self).__init__()

        self.convLayer = nn.Sequential(nn.Conv2d(in_channels=in_channels,
                                                 out_channels=out_channels,
                                                 kernel_size=kernel_size,
                                                 stride=stride,
                                                 padding=padding),
                                       nn.InstanceNorm2d(num_features=out_channels,
                                                         affine=True))
        self.convLayer_gates = nn.Sequential(nn.Conv2d(in_channels=in_channels,
                                                       out_channels=out_channels,
                                                       kernel_size=kernel_size,
                                                       stride=stride,
                                                       padding=padding),
                                             nn.InstanceNorm2d(num_features=out_channels,
                                                               affine=True))

    def forward(self, _input):
        # GLU
        return self.convLayer(_input) * torch.sigmoid(self.convLayer_gates(_input))


##########################################################################################
class Obfuscator(nn.Module):
    def __init__(self, out_channels):
        super(Obfuscator, self).__init__()
#         out_channels = 64
        # 2D Conv Layer 
        self.conv1 = nn.Conv2d(in_channels=1,  # TODO 1 ?
                               out_channels=out_channels//2,
                               kernel_size=(5, 15),
                               stride=(1, 1),
                               padding=(2, 7))

        self.conv1_gates = nn.Conv2d(in_channels=1,  # TODO 1 ?
                                     out_channels=out_channels//2,
                                     kernel_size=(5, 15),
                                     stride=1,
                                     padding=(2, 7))

        # 2D Downsample Layer
        self.downSample1 = downSample_Generator(in_channels=out_channels//2,
                                                out_channels=out_channels*1,
                                                kernel_size=5,
                                                stride=2,
                                                padding=2)
        
        self.downSample2 = downSample_Generator(in_channels=out_channels*1,
                                                out_channels=out_channels*2,
                                                kernel_size=5,
                                                stride=2,
                                                padding=2)

        # 2D -> 1D Conv
#         out_channels = (81*2-1)*2 - 2*2 + 1*4 +0 + 1
        self.conv2dto1dLayer = nn.Sequential(nn.Conv1d(in_channels=out_channels*2*41,
                                                       out_channels=out_channels*2,
                                                       kernel_size=1,
                                                       stride=1,
                                                       padding=0),
                                             nn.InstanceNorm1d(num_features=out_channels*2,
                                                               affine=True))

        # Residual Blocks
        self.residualLayer1 = ResidualLayer(in_channels=out_channels*2, out_channels=out_channels*4, kernel_size=3, stride=1, padding=1)
        self.residualLayer2 = ResidualLayer(in_channels=out_channels*2, out_channels=out_channels*4, kernel_size=3, stride=1, padding=1)
        self.residualLayer3 = ResidualLayer(in_channels=out_channels*2, out_channels=out_channels*4, kernel_size=3, stride=1, padding=1)


        # 1D -> 2D Conv
        self.conv1dto2dLayer = nn.Sequential(nn.Conv1d(in_channels=out_channels*2,
                                                       out_channels=out_channels*2*41,
                                                       kernel_size=1,
                                                       stride=1,
                                                       padding=0),
                                             nn.InstanceNorm1d(num_features=out_channels*2*41,
                                                               affine=True))

        # UpSample Layer
#         self.upSample1 = self.upSample(in_channels=out_channels*2,
#                                        out_channels=out_channels*4,
#                                        kernel_size=5,
#                                        stride=1,
#                                        padding=2)

#         self.upSample2 = self.upSample(in_channels=out_channels*1,
#                                        out_channels=out_channels*2,
#                                        kernel_size=5,
#                                        stride=1,
#                                        padding=2)
        
#         self.lastConvLayer = nn.Conv2d(in_channels=out_channels//2,
#                                        out_channels=1,
#                                        kernel_size=(5, 15),
#                                        stride=(1, 1),
#                                        padding=(2, 7))
        
        self.deconv1 = nn.Sequential(
                nn.ConvTranspose2d(out_channels*2, out_channels*2, 3, stride=(2, 2), padding=(1, 1), output_padding=(0, 1), dilation = (1, 1)),
                nn.Upsample(scale_factor=(1, 1)),
                nn.BatchNorm2d(out_channels*2),
                nn.LeakyReLU(0.2),
            )
        self.deconv2 = nn.Sequential(
                nn.ConvTranspose2d(out_channels*2, out_channels, 3, stride=(2, 2), padding=(1, 1), output_padding=(0, 1), dilation = (1, 1)),
                nn.Upsample(scale_factor=(1, 1)),
                nn.BatchNorm2d(out_channels),
                nn.LeakyReLU(0.2),
            )
        self.deconv3 = nn.Sequential(
                nn.ConvTranspose2d(out_channels, out_channels//2, 3, stride=(1, 1), padding=(1, 1), output_padding=(0, 0), dilation = (1, 1)),
                nn.Upsample(scale_factor=(1, 1)),
                nn.BatchNorm2d(out_channels//2),
                nn.LeakyReLU(0.2),
            )
        self.deconv_last = nn.Sequential(
                nn.ConvTranspose2d(out_channels//2, 1, 3, stride=(1, 1), padding=(1, 1), output_padding=(0, 0), dilation = (1, 1)),
                nn.Upsample(scale_factor=(1, 1)),
                nn.BatchNorm2d(1),
#                 nn.LeakyReLU(),
            )
        
#         self.linear = nn.Sequential(nn.ConvTranspose2d(1, 1, kernel_size=(1, 1), stride=(1, 1), padding=(2, 0), dilation = (2, 2), output_padding = (1, 0)))

    def downSample(self, in_channels, out_channels, kernel_size, stride, padding):
        self.ConvLayer = nn.Sequential(nn.Conv1d(in_channels=in_channels,
                                                 out_channels=out_channels,
                                                 kernel_size=kernel_size,
                                                 stride=stride,
                                                 padding=padding),
                                       nn.InstanceNorm1d(
                                           num_features=out_channels,
                                           affine=True),
                                       GLU())

        return self.ConvLayer

    def upSample(self, in_channels, out_channels, kernel_size, stride, padding):
        self.convLayer = nn.Sequential(nn.Conv2d(in_channels=in_channels,
                                                 out_channels=out_channels,
                                                 kernel_size=kernel_size,
                                                 stride=stride,
                                                 padding=padding),
                                       nn.PixelShuffle(upscale_factor=2),
                                       nn.InstanceNorm2d(
                                           num_features=out_channels // 4, 
                                           affine=True),
                                       GLU())
        return self.convLayer
    
    def forward(self, _input):
        # GLU
#         print("Generator forward input: ", _input.shape)
#         _input = _input.unsqueeze(1)
#         print("Generator forward _input: ", _input.shape)
#         _input = torch.sigmoid(_input)*2-1
        if b_print == True: print("\tInput: ", _input.shape)
        conv1 = self.conv1(_input) * torch.sigmoid(self.conv1_gates(_input))
        if b_print == True: print("\tGenerator forward conv1: ", conv1.shape)

        # DownloadSample
        downsample1 = self.downSample1(conv1)
        if b_print == True: print("\tGenerator forward downsample1: ", downsample1.shape)
        downsample2 = self.downSample2(downsample1)
        if b_print == True: print("\tGenerator forward downsample2: ", downsample2.shape)

        # 2D -> 1D
        # reshape
#         print("downsample2.size(0)", downsample2.size(0))
        reshape2dto1d = downsample2.view(downsample2.size(0), downsample2.shape[1]*downsample2.shape[2], downsample2.shape[3])
        reshape2dto1d = reshape2dto1d.squeeze(2)
        if b_print == True: print("\tGenerator forward reshape2dto1d: ", reshape2dto1d.shape)
        conv2dto1d_layer = self.conv2dto1dLayer(reshape2dto1d)
        if b_print == True: print("\tGenerator forward conv2dto1d_layer: ", conv2dto1d_layer.shape)

#         output = conv2dto1d_layer
#         for r in range(5):
#             output = self.residualLayer1(output)
        residual_layer_1 = self.residualLayer1(conv2dto1d_layer)
        residual_layer_2 = self.residualLayer2(residual_layer_1)
        residual_layer_3 = self.residualLayer3(residual_layer_2)
        last_residual_layer = residual_layer_3

        if b_print == True: print("\tGenerator forward residual_layer_6: ", last_residual_layer.shape)

        # 1D -> 2D
        conv1dto2d_layer = self.conv1dto2dLayer(last_residual_layer)
        if b_print == True: print("\tGenerator forward conv1dto2d_layer: ", conv1dto2d_layer.shape)
        # reshape
        reshape1dto2d = conv1dto2d_layer.unsqueeze(2)
        reshape1dto2d = reshape1dto2d.view(reshape1dto2d.size(0), downsample2.shape[1], downsample2.shape[2], -1)
        if b_print == True: print("\tGenerator forward reshape1dto2d: ", reshape1dto2d.shape)
        
        deconv1 = self.deconv1(reshape1dto2d)
        if b_print == True: print("\tGenerator forward deconv1: ", deconv1.shape)
        deconv2 = self.deconv2(deconv1)
        if b_print == True: print("\tGenerator forward deconv2: ", deconv2.shape)
        deconv3 = self.deconv3(deconv2)
        if b_print == True: print("\tGenerator forward deconv3: ", deconv3.shape)
        deconv_last = self.deconv_last(deconv3)
        if b_print == True: print("\tGenerator forward deconv_last: ", deconv_last.shape)
        output = deconv_last
        output = torch.sigmoid(output)*2-1
        return output


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
torch.backends.cudnn.enabled=False
torch.backends.cudnn.benchmark = True

# import torchvision
# import torchvision.transforms as transforms

import os
import argparse


from deepspeech_pytorch.configs.train_config import SpectConfig, BiDirectionalConfig, OptimConfig, AdamConfig, \
    SGDConfig, UniDirectionalConfig

from utils import progress_bar
from torch.autograd import Variable
from deepspeech_pytorch.configs.train_config import SpectConfig, AugmentationConfig, DataConfig, DeepSpeechConfig
from deepspeech_pytorch.configs.inference_config import TranscribeConfig
# from dataloader import SpectrogramDataset, AudioDataLoader
from deepspeech_pytorch.utils import load_decoder, load_model
import numpy as np
import json

dataset = "EmoV_2"
# dataset = "LS_460_et"
# label_scale = "coarse"
# attacked_label = 'fine'
label_scale = "fine"
attacked_label = 'coarse'

model_type = "cycgan"
#v1 - ctcloss, 10 layer rnn, out_channels 128
#v1 - ctcloss, 10 layer rnn, out_channels 64, lr -3, r 0.1
version = "3layer_len800_v1"
state_name = "0424_attacker_%s_%s_%s_v%s"%(dataset, label_scale, model_type, version)

learning_rate = 0
ratio = 1
batch_size = 40
num_data = 120

max_scale = 40

# target_ckt = "/project/weicheng/privacy/PrivacyAwareAudioClassification/task_checkpoint/0424_deepspeech_%s_%s.t7"%(dataset, label_scale)
target_model = DS2Classifier(labels=[0, 1])
# target_model = torch.nn.DataParallel(target_model, device_ids=range(torch.cuda.device_count())).cuda()
print("classifier Number of parameters: %.3fM"%(count_parameters(target_model)))

# obfuscator_ckt = "/project/weicheng/privacy/deepspeech2/torch/0410v1/stg22/0424_obfuscator_EmoV_2_%s_cycgan_v3layer_len1k_zscore_segpred_v5.t7"%attacked_label
obfuscator_ckt = "/project/weicheng/privacy/deepspeech2/torch/0410v1/stg22/0424_obfuscator_EmoV_2_%s_cycgan_v3layer_len800_v1.t7"%attacked_label
obfuscator = Obfuscator(32)
print("obfuscator Number of parameters: %.3fM"%(count_parameters(obfuscator)))

inputs = np.load("Neutral_1-28_0023.npy")
print(inputs.shape)

# inputs = torch.from_numpy(np.asarray([inputs])).float()
# inputs = torch.unsqueeze(inputs, 1)
inputs = torch.from_numpy(inputs)
print(inputs)

import time

start = time.time()

inputs = obfuscator(inputs)

# Grab Currrent Time After Running the Code
end = time.time()

#Subtract Start Time from The End Time
total_time = end - start
print("\n"+ str(total_time))

